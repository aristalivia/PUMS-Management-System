@extends('template')
@section('content')
<div class="content">
        <div class="row">
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
            <a href="{{url('supplier')}}">
              <!--box supplier-->
              <div class="card-body ">
                <div class="row">
                  <div class="col-5 col-md-4">
                    <div class="icon-big text-center icon-warning">
                      <i> <svg id="adb8fb9f-b5c8-40ff-acb7-8431aefaa0c5" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 457.51 389.71"><defs><style>.fec0e6af-51e9-402d-bcab-8906bbc5e334{fill:#fce1cd;}.a4b7016e-8486-41b2-a8e4-ade7d90fce37,.af5cd35d-98b7-427e-84a4-bd298aa3f328{fill:#ff9d4d;}.a27c3e35-480b-46b6-81f1-f1ea378a406f,.a4b7016e-8486-41b2-a8e4-ade7d90fce37,.a98214ed-ac8a-4038-a59c-0b2bc3e04c65,.acde95c2-e438-4104-b637-3291e0542715,.ad580e8f-4294-450d-a08e-d1a4c9cc7569,.af43ce15-38ee-4013-87ac-7c65e36f5326,.af5cd35d-98b7-427e-84a4-bd298aa3f328,.b3d8b6e7-6370-4c4f-8548-242410aee8f3,.bf13c46e-cc70-4a60-a011-6b8a62f21dfa{stroke:#fcfcfc;stroke-miterlimit:10;}.af5cd35d-98b7-427e-84a4-bd298aa3f328,.b3d8b6e7-6370-4c4f-8548-242410aee8f3{stroke-width:0.93px;}.b3d8b6e7-6370-4c4f-8548-242410aee8f3{fill:#f7f4f2;}.ac9b3f27-0f38-4839-b861-cbd826b38cfb{fill:#d3bfb2;}.a4b7016e-8486-41b2-a8e4-ade7d90fce37{stroke-width:1.13px;}.ad580e8f-4294-450d-a08e-d1a4c9cc7569,.bf13c46e-cc70-4a60-a011-6b8a62f21dfa{fill:#7c502f;}.a98214ed-ac8a-4038-a59c-0b2bc3e04c65,.ad580e8f-4294-450d-a08e-d1a4c9cc7569{stroke-width:0.86px;}.a27c3e35-480b-46b6-81f1-f1ea378a406f,.a98214ed-ac8a-4038-a59c-0b2bc3e04c65,.acde95c2-e438-4104-b637-3291e0542715,.af43ce15-38ee-4013-87ac-7c65e36f5326{fill:#f7f7f7;}.af43ce15-38ee-4013-87ac-7c65e36f5326{stroke-width:0.92px;}.a27c3e35-480b-46b6-81f1-f1ea378a406f,.bf13c46e-cc70-4a60-a011-6b8a62f21dfa{stroke-width:1.31px;}.acde95c2-e438-4104-b637-3291e0542715{stroke-width:1.4px;}</style></defs><path class="fec0e6af-51e9-402d-bcab-8906bbc5e334" d="M83.25,52.11H190a7.73,7.73,0,0,1,7.73,7.73v75.89a38.63,38.63,0,0,1-38.63,38.63h-45a38.63,38.63,0,0,1-38.63-38.63V59.84A7.73,7.73,0,0,1,83.25,52.11Z"/><path class="af5cd35d-98b7-427e-84a4-bd298aa3f328" d="M127.94.46h17.42a62,62,0,0,1,62,62V83.09a20.66,20.66,0,0,1-20.66,20.66H86.61A20.66,20.66,0,0,1,65.95,83.09V62.46a62,62,0,0,1,62-62Z"/><path class="b3d8b6e7-6370-4c4f-8548-242410aee8f3" d="M65.95,78.17h141.4a0,0,0,0,1,0,0v4.92a20.66,20.66,0,0,1-20.66,20.66H86.61A20.66,20.66,0,0,1,65.95,83.09V78.17A0,0,0,0,1,65.95,78.17Z"/><path class="ac9b3f27-0f38-4839-b861-cbd826b38cfb" d="M72.07,103.76h3.67a0,0,0,0,1,0,0V132a0,0,0,0,1,0,0H72.07a8.49,8.49,0,0,1-8.49-8.49V112.25A8.49,8.49,0,0,1,72.07,103.76Z"/><path class="ac9b3f27-0f38-4839-b861-cbd826b38cfb" d="M233.87,166.09h3.63a0,0,0,0,1,0,0v28.25a0,0,0,0,1,0,0h-3.63a8.47,8.47,0,0,1-8.47-8.47V174.56A8.47,8.47,0,0,1,233.87,166.09Z" transform="translate(435.27 299.67) rotate(180)"/><path class="ac9b3f27-0f38-4839-b861-cbd826b38cfb" d="M116.8,174.36h36.64a0,0,0,0,1,0,0V197a16.53,16.53,0,0,1-16.53,16.53h-3.58A16.53,16.53,0,0,1,116.8,197V174.36a0,0,0,0,1,0,0Z"/><path class="a4b7016e-8486-41b2-a8e4-ade7d90fce37" d="M87.35,199.2H182.9A86.78,86.78,0,0,1,269.68,286V389.05a0,0,0,0,1,0,0H.57a0,0,0,0,1,0,0V286A86.78,86.78,0,0,1,87.35,199.2Z"/><rect class="ad580e8f-4294-450d-a08e-d1a4c9cc7569" x="314.3" y="101.11" width="113.02" height="113.02"/><rect class="a98214ed-ac8a-4038-a59c-0b2bc3e04c65" x="358.21" y="101.11" width="25.2" height="25.2"/><rect class="af43ce15-38ee-4013-87ac-7c65e36f5326" x="383.41" y="157.62" width="43.91" height="16.66"/><rect class="af43ce15-38ee-4013-87ac-7c65e36f5326" x="383.41" y="181.38" width="43.91" height="16.66"/><rect class="bf13c46e-cc70-4a60-a011-6b8a62f21dfa" x="284.82" y="217.07" width="171.99" height="171.99"/><rect class="a27c3e35-480b-46b6-81f1-f1ea378a406f" x="351.64" y="217.07" width="38.34" height="38.34"/><rect class="acde95c2-e438-4104-b637-3291e0542715" x="389.98" y="303.06" width="66.82" height="25.35"/><rect class="acde95c2-e438-4104-b637-3291e0542715" x="389.98" y="339.21" width="66.82" height="25.35"/></svg></i>
                    </div>
                  </div>
                  <div class="col-7 col-md-8">
                    <div class="numbers">
                      <p class="card-category">Supplier</p>
                      <!-- <p class="card-title">150GB<p> -->
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-refresh"></i>
                  Update Now
                </div>
              </div>
            </div></a>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
            <a href="{{url('bahanbaku')}}">
              <div class="card-body ">
                <div class="row">
                  <div class="col-5 col-md-4">
                    <div class="icon-big text-center icon-warning">
                      <i><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 350.1 384.36"><defs><style>.a,.d{fill:#7c502f;}.a,.b,.c,.d,.e,.f{stroke:#fcfcfc;}.a,.b,.c,.d,.e,.f,.g{stroke-miterlimit:10;}.a,.b{stroke-width:1.05px;}.b,.c,.e,.f{fill:#f7f7f7;}.c{stroke-width:1.12px;}.d,.e{stroke-width:1.59px;}.f{stroke-width:1.71px;}.g{fill:#fff;stroke:#ff9d4d;stroke-width:11.08px;}</style></defs><rect class="a" x="40" y="0.52" width="150.29" height="126.29"/><rect class="b" x="98.4" y="0.52" width="33.51" height="28.15"/><rect class="c" x="131.9" y="63.67" width="58.39" height="18.62"/><rect class="c" x="131.9" y="90.21" width="58.39" height="18.62"/><rect class="d" x="0.8" y="130.09" width="228.7" height="192.17"/><rect class="e" x="89.66" y="130.09" width="50.99" height="42.84"/><rect class="f" x="140.64" y="226.18" width="88.86" height="28.33"/><rect class="f" x="140.64" y="266.57" width="88.86" height="28.33"/><rect class="g" x="158.33" y="146.21" width="186.23" height="232.61" rx="15.83"/><rect class="g" x="195.94" y="121.44" width="111.08" height="47.19" rx="7.92"/><line class="g" x1="177.54" y1="217.78" x2="200.91" y2="237.57"/><line class="g" x1="236.47" y1="198.41" x2="198.82" y2="236.06"/><line class="g" x1="177.3" y1="269.56" x2="200.67" y2="289.35"/><line class="g" x1="236.23" y1="250.19" x2="198.58" y2="287.84"/><line class="g" x1="176.77" y1="316.73" x2="200.14" y2="336.52"/><line class="g" x1="235.7" y1="297.35" x2="198.05" y2="335"/><line class="g" x1="248.82" y1="217.99" x2="322.39" y2="217.99"/><line class="g" x1="248.82" y1="269.77" x2="322.39" y2="269.77"/><line class="g" x1="248.82" y1="323.02" x2="322.39" y2="323.02"/></svg></i>
                    </div>
                  </div>
                  <div class="col-7 col-md-8">
                    <div class="numbers">
                      <p class="card-category">Bahan Baku</p>
                      <!-- <p class="card-title">$ 1,345<p> -->
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-refresh"></i>
                  Update Now
                </div>
              </div>
            </div></a>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
            <a href="{{url('produksi')}}">
              <div class="card-body ">
                <div class="row">
                  <div class="col-5 col-md-4">
                    <div class="icon-big text-center icon-warning">
                      <i><svg id="a2adefe7-a28d-4451-b4e0-a905da48d6ad" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 484.35 281.34"><defs><style>.b4a702c7-f851-4523-b8fe-a6d02a3e7338{fill:#fce1cd;}.e16028e0-a264-44d9-8d02-1bdf597e4740,.fa48a171-6d13-4a76-bbee-0e90c49da977{fill:#ff9d4d;}.a3387266-0ecf-4297-a8fb-18bffd08b016,.b9e9143b-c37f-4ff0-af70-77789c3fbfb1,.e16028e0-a264-44d9-8d02-1bdf597e4740,.e7b69212-a3b2-4f22-83b3-f33dac00d090,.fa48a171-6d13-4a76-bbee-0e90c49da977,.fd6ba12d-87bd-4f75-a286-c3383f3b3b47{stroke:#fcfcfc;}.a3387266-0ecf-4297-a8fb-18bffd08b016,.a6f2bd57-3bd2-427d-9bf0-c87652e9c806,.b9e9143b-c37f-4ff0-af70-77789c3fbfb1,.e16028e0-a264-44d9-8d02-1bdf597e4740,.e7b69212-a3b2-4f22-83b3-f33dac00d090,.fa48a171-6d13-4a76-bbee-0e90c49da977,.fd6ba12d-87bd-4f75-a286-c3383f3b3b47{stroke-miterlimit:10;}.a3387266-0ecf-4297-a8fb-18bffd08b016,.e16028e0-a264-44d9-8d02-1bdf597e4740{stroke-width:0.67px;}.a3387266-0ecf-4297-a8fb-18bffd08b016{fill:#f7f4f2;}.ee6b6e3a-7f65-4523-aca9-4849e57b9d31{fill:#d3bfb2;}.b9e9143b-c37f-4ff0-af70-77789c3fbfb1{fill:#7c502f;}.b9e9143b-c37f-4ff0-af70-77789c3fbfb1,.fd6ba12d-87bd-4f75-a286-c3383f3b3b47{stroke-width:0.84px;}.e7b69212-a3b2-4f22-83b3-f33dac00d090,.fd6ba12d-87bd-4f75-a286-c3383f3b3b47{fill:#f7f7f7;}.e7b69212-a3b2-4f22-83b3-f33dac00d090{stroke-width:0.9px;}.a6f2bd57-3bd2-427d-9bf0-c87652e9c806{fill:#fff;stroke:#000;stroke-width:8.95px;}.fa48a171-6d13-4a76-bbee-0e90c49da977{stroke-width:0.82px;}</style></defs><path class="b4a702c7-f851-4523-b8fe-a6d02a3e7338" d="M60.11,37.63h77.11a5.58,5.58,0,0,1,5.58,5.58V98a27.89,27.89,0,0,1-27.89,27.89H82.43A27.89,27.89,0,0,1,54.53,98V43.21A5.58,5.58,0,0,1,60.11,37.63Z"/><path class="e16028e0-a264-44d9-8d02-1bdf597e4740" d="M92.38.34H105A44.76,44.76,0,0,1,149.72,45.1V60A14.92,14.92,0,0,1,134.8,74.92H62.54A14.92,14.92,0,0,1,47.62,60V45.1A44.76,44.76,0,0,1,92.38.34Z"/><path class="a3387266-0ecf-4297-a8fb-18bffd08b016" d="M47.62,56.45h102.1a0,0,0,0,1,0,0V60A14.92,14.92,0,0,1,134.8,74.92H62.54A14.92,14.92,0,0,1,47.62,60V56.45A0,0,0,0,1,47.62,56.45Z"/><path class="ee6b6e3a-7f65-4523-aca9-4849e57b9d31" d="M52,74.92h2.65a0,0,0,0,1,0,0v20.4a0,0,0,0,1,0,0H52a6.13,6.13,0,0,1-6.13-6.13V81.05A6.13,6.13,0,0,1,52,74.92Z"/><path class="ee6b6e3a-7f65-4523-aca9-4849e57b9d31" d="M166.48,189.05h2.62a0,0,0,0,1,0,0v20.4a0,0,0,0,1,0,0h-2.62a6.12,6.12,0,0,1-6.12-6.12v-8.17A6.12,6.12,0,0,1,166.48,189.05Z" transform="translate(311.91 285.51) rotate(180)"/><path class="ee6b6e3a-7f65-4523-aca9-4849e57b9d31" d="M84.34,125.9H110.8a0,0,0,0,1,0,0v16.33a11.94,11.94,0,0,1-11.94,11.94H96.28a11.94,11.94,0,0,1-11.94-11.94V125.9a0,0,0,0,1,0,0Z"/><rect class="b9e9143b-c37f-4ff0-af70-77789c3fbfb1" x="337.9" y="84.8" width="110.47" height="110.47"/><rect class="fd6ba12d-87bd-4f75-a286-c3383f3b3b47" x="380.82" y="84.8" width="24.63" height="24.63"/><rect class="e7b69212-a3b2-4f22-83b3-f33dac00d090" x="405.45" y="140.03" width="42.92" height="16.28"/><rect class="e7b69212-a3b2-4f22-83b3-f33dac00d090" x="405.45" y="163.25" width="42.92" height="16.28"/><rect class="b9e9143b-c37f-4ff0-af70-77789c3fbfb1" x="208.16" y="84.8" width="110.47" height="110.47"/><rect class="fd6ba12d-87bd-4f75-a286-c3383f3b3b47" x="251.08" y="84.8" width="24.63" height="24.63"/><rect class="e7b69212-a3b2-4f22-83b3-f33dac00d090" x="275.71" y="140.03" width="42.92" height="16.28"/><rect class="e7b69212-a3b2-4f22-83b3-f33dac00d090" x="275.71" y="163.25" width="42.92" height="16.28"/><path class="a6f2bd57-3bd2-427d-9bf0-c87652e9c806" d="M187,201.09H457.49a22.38,22.38,0,0,1,22.38,22.38v23.78a22.38,22.38,0,0,1-22.38,22.38H187a0,0,0,0,1,0,0V201.09A0,0,0,0,1,187,201.09Z"/><path class="fa48a171-6d13-4a76-bbee-0e90c49da977" d="M63.07,143.84h69a62.66,62.66,0,0,1,62.66,62.66v74.43a0,0,0,0,1,0,0H.41a0,0,0,0,1,0,0V206.5A62.66,62.66,0,0,1,63.07,143.84Z"/><circle class="fa48a171-6d13-4a76-bbee-0e90c49da977" cx="250.62" cy="235.37" r="15.4"/><circle class="fa48a171-6d13-4a76-bbee-0e90c49da977" cx="294.19" cy="235.37" r="15.4"/><circle class="fa48a171-6d13-4a76-bbee-0e90c49da977" cx="337.9" cy="235.37" r="15.4"/><circle class="fa48a171-6d13-4a76-bbee-0e90c49da977" cx="380.82" cy="235.37" r="15.4"/><circle class="fa48a171-6d13-4a76-bbee-0e90c49da977" cx="426.91" cy="235.37" r="15.4"/></svg> </i>
                    </div>
                  </div>
                  <div class="col-7 col-md-8">
                    <div class="numbers">
                      <p class="card-category">Produksi</p>
                      <!-- <p class="card-title">23<p> -->
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-refresh"></i>
                  Update Now
                </div>
              </div>
            </div></a>
          </div>
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="card card-stats">
            <a href="{{url('gudang')}}">
              <div class="card-body ">
                <div class="row">
                  <div class="col-5 col-md-4">
                    <div class="icon-big text-center icon-warning">
                      <i><svg id="b20c75c4-9ed4-4e5f-bd33-6f55a8967d3a" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256.55 311.43"><defs><style>.f6a70752-7657-4acc-8e22-dbf4af649c99{fill:#ff9d4d;}.bf79f235-7228-46d2-8c72-4032f82e0845,.ec02c7b4-d63f-40ee-bbca-6a15bd5a969c,.f6a70752-7657-4acc-8e22-dbf4af649c99{stroke:#000;}.aab24e36-1c5e-43eb-af45-630355970b97,.ad69de70-fb06-49d6-b108-fafbf2be0bdc,.bf79f235-7228-46d2-8c72-4032f82e0845,.e8a8f9d4-7e62-4046-86b4-52a62006dd66,.ec02c7b4-d63f-40ee-bbca-6a15bd5a969c,.f6a70752-7657-4acc-8e22-dbf4af649c99{stroke-miterlimit:10;}.bf79f235-7228-46d2-8c72-4032f82e0845,.f6a70752-7657-4acc-8e22-dbf4af649c99{stroke-width:5.88px;}.bf79f235-7228-46d2-8c72-4032f82e0845{fill:none;}.ec02c7b4-d63f-40ee-bbca-6a15bd5a969c{fill:#fff;stroke-width:3.42px;}.ad69de70-fb06-49d6-b108-fafbf2be0bdc{fill:#7c502f;}.aab24e36-1c5e-43eb-af45-630355970b97,.ad69de70-fb06-49d6-b108-fafbf2be0bdc,.e8a8f9d4-7e62-4046-86b4-52a62006dd66{stroke:#fcfcfc;}.aab24e36-1c5e-43eb-af45-630355970b97,.ad69de70-fb06-49d6-b108-fafbf2be0bdc{stroke-width:0.28px;}.aab24e36-1c5e-43eb-af45-630355970b97,.e8a8f9d4-7e62-4046-86b4-52a62006dd66{fill:#f7f7f7;}.e8a8f9d4-7e62-4046-86b4-52a62006dd66{stroke-width:0.3px;}</style></defs><polygon class="f6a70752-7657-4acc-8e22-dbf4af649c99" points="128.27 4.16 249.44 125.33 7.1 125.33 128.27 4.16"/><rect class="f6a70752-7657-4acc-8e22-dbf4af649c99" x="7.1" y="125.33" width="242.34" height="183.16"/><line class="bf79f235-7228-46d2-8c72-4032f82e0845" x1="110.7" y1="61.58" x2="142.21" y2="61.58"/><line class="bf79f235-7228-46d2-8c72-4032f82e0845" x1="99.03" y1="82.51" x2="153.89" y2="82.51"/><line class="bf79f235-7228-46d2-8c72-4032f82e0845" x1="82.39" y1="103.44" x2="170.52" y2="103.44"/><rect class="ec02c7b4-d63f-40ee-bbca-6a15bd5a969c" x="66.22" y="169.54" width="124.1" height="138.94"/><rect class="ec02c7b4-d63f-40ee-bbca-6a15bd5a969c" x="61.24" y="161.9" width="134.45" height="13.04"/><rect class="ad69de70-fb06-49d6-b108-fafbf2be0bdc" x="70.69" y="223.6" width="36.3" height="36.3"/><rect class="aab24e36-1c5e-43eb-af45-630355970b97" x="84.8" y="223.6" width="8.09" height="8.09"/><rect class="e8a8f9d4-7e62-4046-86b4-52a62006dd66" x="92.89" y="241.75" width="14.1" height="5.35"/><rect class="e8a8f9d4-7e62-4046-86b4-52a62006dd66" x="92.89" y="249.38" width="14.1" height="5.35"/><rect class="ad69de70-fb06-49d6-b108-fafbf2be0bdc" x="70.69" y="265.42" width="36.3" height="36.3"/><rect class="aab24e36-1c5e-43eb-af45-630355970b97" x="84.8" y="265.42" width="8.09" height="8.09"/><rect class="e8a8f9d4-7e62-4046-86b4-52a62006dd66" x="92.89" y="283.57" width="14.1" height="5.35"/><rect class="e8a8f9d4-7e62-4046-86b4-52a62006dd66" x="92.89" y="291.19" width="14.1" height="5.35"/><rect class="ad69de70-fb06-49d6-b108-fafbf2be0bdc" x="112.51" y="265.42" width="36.3" height="36.3"/><rect class="aab24e36-1c5e-43eb-af45-630355970b97" x="126.61" y="265.42" width="8.09" height="8.09"/><rect class="e8a8f9d4-7e62-4046-86b4-52a62006dd66" x="134.71" y="283.57" width="14.1" height="5.35"/><rect class="e8a8f9d4-7e62-4046-86b4-52a62006dd66" x="134.71" y="291.19" width="14.1" height="5.35"/></svg></i>
                    </div>
                  </div>
                  <div class="col-7 col-md-8">
                    <div class="numbers">
                      <p class="card-category">Gudang</p>
                      <!-- <p class="card-title">+45K<p> -->
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-refresh"></i>
                  Update Now
                </div>
              </div>
            </div>
          </div></a>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card ">
              <div class="card-header ">
                <h5 class="card-title">Produksi</h5>
                <p class="card-category">24 Hours performance</p>
              </div>
              <div class="card-body ">
                <canvas id=chartHours width="400" height="100"></canvas>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-history"></i> Updated 3 minutes ago
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--<div class="row">
          <div class="col-md-4">
            <div class="card ">
              <div class="card-header ">
                <h5 class="card-title">Email Statistics</h5>
                <p class="card-category">Last Campaign Performance</p>
              </div>
              <div class="card-body ">
                <canvas id="chartEmail"></canvas>
              </div>
              <div class="card-footer ">
                <div class="legend">
                  <i class="fa fa-circle text-primary"></i> Opened
                  <i class="fa fa-circle text-warning"></i> Read
                  <i class="fa fa-circle text-danger"></i> Deleted
                  <i class="fa fa-circle text-gray"></i> Unopened
                </div>
                <hr>
                <div class="stats">
                  <i class="fa fa-calendar"></i> Number of emails sent
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-8">
            <div class="card card-chart">
              <div class="card-header">
                <h5 class="card-title">NASDAQ: AAPL</h5>
                <p class="card-category">Line Chart with Points</p>
              </div>
              <div class="card-body">
                <canvas id="speedChart" width="400" height="100"></canvas>
              </div>
              <div class="card-footer">
                <div class="chart-legend">
                  <i class="fa fa-circle text-info"></i> Tesla Model S
                  <i class="fa fa-circle text-warning"></i> BMW 5 Series
                </div>
                <hr />
                <div class="card-stats">
                  <i class="fa fa-check"></i> Data information certified
                </div>
              </div>
            </div>
          </div>
        </div> -->
      </div>
      @endsection