@extends('template')
@section('supplier')
<div class="content">
        <div class="row">
          <div class="col-md-12">

              <button type="button" class="btn btn--primary" data-toggler="modal" data-target="#modalSupplierTambah">
                Tambah Supplier
              </button>

            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Supplier</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>No</th>
                      <th>Id Supplier</th>
                      <th>Nama Bisnis</th>
                      <th>Nama Bahan</th>
                      <th>Kontak</th>
                      <th class="text-center">Update</th>
                    </thead>

                    <tbody>
                      @foreach ($supplier as $index=>$supplier)
                      <tr>
                        <td align="center" scope="row">{{ $index + $buku->firstItem() }}</td>
                        <td>{{$supplier->id_supplier}}</td>
                        <td>{{$supplier->nama_bisnis}}</td>
                        <td>{{$supplier->nama_bahan}}</td>
                        <td>{{$supplier->kontak}}</td>

                        <td class="text-center">
                         <a onclick="editForm('')" class="btn btn-primary btn-xs" button type="button" data-toggle="modal" data-target="#modalSuuplierEdit{{$supplier->id_supplier}}"><i class="glyphicon glyphicon-edit"></i> Edit</a>
                            Edit
                        </button>
                         <!-- Awal Modal EDIT data supplier -->
                        <div class="modal fade" id="modalSupplierEdit{{$supplier->id_supplier}}" tabindex="-1" role="dialog" aria-labelledby="modalSupplierEditLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modalSupplierEditLabel">Form Edit Data Supplier</h5>
                                    </div>
                                    <div class="modal-body">

                                        <form name="formsupplieredit" id="formsupplieredit" action="/supplier/edit/{{ $supplier->id_supplier}} " method="post" enctype="multipart/form-data">
                                            @csrf
                                            {{ method_field('PUT') }}
                                            <div class="form-group row">
                                                <label for="id_supplier" class="col-sm-4 col-form-label">Id Supplier</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="kode_supplier" name="kode_supplier" placeholder="Masukan Id Supplier">
                                                </div>
                                            </div>

                                            <p>
                                            <div class="form-group row">
                                                <label for="nama_bisnis" class="col-sm-4 col-form-label">Nama Bisnis</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="nama_bisnis" name="nama_bisnis" value="{{ $supplier->nama_bisnis}}">
                                                </div>
                                            </div>

                                            <p>
                                            <div class="form-group row">
                                                <label for="nama_bahan" class="col-sm-4 col-form-label">Nama Bahan</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="nama_bahan" name="nama_bahan" value="{{ $supplier->nama_bahan}}">
                                                </div>
                                            </div>

                                            <p>
                                            <div class="form-group row">
                                                <label for="kontak" class="col-sm-4 col-form-label">Kontak</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="kontak" name="kontak" value="{{ $supplier->kontak}}">
                                                </div>
                                            </div>

                                            <p>
                                            <div class="modal-footer">
                                                <button type="button" name="tutup" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                                <button type="submit" name="bukutambah" class="btn btn-success">Edit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Akhir Modal EDIT data buku -->
    
                        <button>
                          <a href="supplier/hapus/{{$supplier->id_supplier}}" class="btn btn-danger btn-xs" onclick="return confirm('Yakin mau dihapus?')"><i class="glyphicon glyphicon-trash"></i>
                              Delete
                          </button>

    <!--awal pagination
    Halaman : {{ $buku->currentPage() }} <br />
    Jumlah Data : {{ $buku->total() }} <br />
    Data Per Halaman : {{ $buku->perPage() }} <br />

    {{ $buku->links() }}
    akhir pagination-->

    <!-- Awal Modal tambah data supplier -->
    <div class="modal fade" id="modalSupplierTambah" tabindex="-1" role="dialog" aria-labelledby="modalSupplierTambahLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalSupplierTambahLabel">Form Input Data Supplier</h5>
                </div>
                <div class="modal-body">
                    <form name="formsuppliertambah" id="formsuppliertambah" action="/supplier/tambah " method="post" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group row">
                            <label for="id_supplier" class="col-sm-4 col-form-label">Kode Supplier</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="kode_supplier" name="kode_supplier" placeholder="Masukan Kode Supplier">
                            </div>
                        </div>

                        <p>
                        <div class="form-group row">
                            <label for="nama_bisnis" class="col-sm-4 col-form-label">Nama Bisnis</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="nama_bisnis" name="nama_bisnis" value="{{ $supplier->nama_bisnis}}">
                            </div>
                        </div>

                        <p>
                        <div class="form-group row">
                            <label for="nama_bahan" class="col-sm-4 col-form-label">Nama Bahan</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="nama_bahan" name="nama_bahan" value="{{ $supplier->nama_bahan}}">
                            </div>
                        </div>                    

                        <p>
                        <div class="form-group row">
                            <label for="kontak" class="col-sm-4 col-form-label">Kontak</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="kontak" name="kontak" value="{{ $supplier->kontak}}">
                            </div>
                        </div>

                        <p>
                        <div class="modal-footer">
                            <button type="button" name="tutup" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                            <button type="submit" name="suppliertambah" class="btn btn-success">Tambah</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Akhir Modal tambah data buku -->
                        </a>
                        </td>   
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer footer-black  footer-white ">
        <div class="container-fluid">
          <div class="row">
            <nav class="footer-nav">
              <ul>
                <li><a href="https://www.creative-tim.com" target="_blank">PUMS</a></li>
                <li><a href="https://www.creative-tim.com/blog" target="_blank">Blog</a></li>
                <li><a href="https://www.creative-tim.com/license" target="_blank">Licenses</a></li>
              </ul>
            </nav>
            <div class="credits ml-auto">
              <span class="copyright">
                © <script>
                  document.write(new Date().getFullYear())
                </script>, made with <i class="fa fa-heart heart"></i> by PUMS
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </div>
@endsection